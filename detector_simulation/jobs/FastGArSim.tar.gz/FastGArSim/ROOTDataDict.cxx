// Do NOT change. Changes will be lost next time file is generated

#define R__DICTIONARY_FILENAME ROOTDataDict
#define R__NO_DEPRECATION

/*******************************************************************/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define G__DICTIONARY
#include "ROOT/RConfig.hxx"
#include "TClass.h"
#include "TDictAttributeMap.h"
#include "TInterpreter.h"
#include "TROOT.h"
#include "TBuffer.h"
#include "TMemberInspector.h"
#include "TInterpreter.h"
#include "TVirtualMutex.h"
#include "TError.h"

#ifndef G__ROOT
#define G__ROOT
#endif

#include "RtypesImp.h"
#include "TIsAProxy.h"
#include "TFileMergeInfo.h"
#include <algorithm>
#include "TCollectionProxyInfo.h"
/*******************************************************************/

#include "TDataMember.h"

// Header files passed as explicit arguments
#include "/exp/dune/app/users/jmartin4/FastGArSim/detector_simulation/include/ROOTDataTypes.hh"

// Header files passed via #pragma extra_include

// The generated code does not explicitly qualify STL entities
namespace std {} using namespace std;

namespace root {
   namespace ROOTDict {
      inline ::ROOT::TGenericClassInfo *GenerateInitInstance();
      static TClass *root_Dictionary();

      // Function generating the singleton type initializer
      inline ::ROOT::TGenericClassInfo *GenerateInitInstance()
      {
         static ::ROOT::TGenericClassInfo 
            instance("root", 0 /*version*/, "", 13,
                     ::ROOT::Internal::DefineBehavior((void*)nullptr,(void*)nullptr),
                     &root_Dictionary, 0);
         return &instance;
      }
      // Insure that the inline function is _not_ optimized away by the compiler
      ::ROOT::TGenericClassInfo *(*_R__UNIQUE_DICT_(InitFunctionKeeper))() = &GenerateInitInstance;  
      // Static variable to force the class initialization
      static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstance(); R__UseDummy(_R__UNIQUE_DICT_(Init));

      // Dictionary for non-ClassDef classes
      static TClass *root_Dictionary() {
         return GenerateInitInstance()->GetClass();
      }

   }
}

namespace ROOT {
   static void *new_rootcLcLTrajectoryPoint(void *p = nullptr);
   static void *newArray_rootcLcLTrajectoryPoint(Long_t size, void *p);
   static void delete_rootcLcLTrajectoryPoint(void *p);
   static void deleteArray_rootcLcLTrajectoryPoint(void *p);
   static void destruct_rootcLcLTrajectoryPoint(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::TrajectoryPoint*)
   {
      ::root::TrajectoryPoint *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::TrajectoryPoint >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::TrajectoryPoint", ::root::TrajectoryPoint::Class_Version(), "", 15,
                  typeid(::root::TrajectoryPoint), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::TrajectoryPoint::Dictionary, isa_proxy, 4,
                  sizeof(::root::TrajectoryPoint) );
      instance.SetNew(&new_rootcLcLTrajectoryPoint);
      instance.SetNewArray(&newArray_rootcLcLTrajectoryPoint);
      instance.SetDelete(&delete_rootcLcLTrajectoryPoint);
      instance.SetDeleteArray(&deleteArray_rootcLcLTrajectoryPoint);
      instance.SetDestructor(&destruct_rootcLcLTrajectoryPoint);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::TrajectoryPoint*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::TrajectoryPoint*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::TrajectoryPoint*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_rootcLcLMomentumPoint(void *p = nullptr);
   static void *newArray_rootcLcLMomentumPoint(Long_t size, void *p);
   static void delete_rootcLcLMomentumPoint(void *p);
   static void deleteArray_rootcLcLMomentumPoint(void *p);
   static void destruct_rootcLcLMomentumPoint(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::MomentumPoint*)
   {
      ::root::MomentumPoint *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::MomentumPoint >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::MomentumPoint", ::root::MomentumPoint::Class_Version(), "", 29,
                  typeid(::root::MomentumPoint), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::MomentumPoint::Dictionary, isa_proxy, 4,
                  sizeof(::root::MomentumPoint) );
      instance.SetNew(&new_rootcLcLMomentumPoint);
      instance.SetNewArray(&newArray_rootcLcLMomentumPoint);
      instance.SetDelete(&delete_rootcLcLMomentumPoint);
      instance.SetDeleteArray(&deleteArray_rootcLcLMomentumPoint);
      instance.SetDestructor(&destruct_rootcLcLMomentumPoint);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::MomentumPoint*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::MomentumPoint*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::MomentumPoint*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_rootcLcLTrajectory(void *p = nullptr);
   static void *newArray_rootcLcLTrajectory(Long_t size, void *p);
   static void delete_rootcLcLTrajectory(void *p);
   static void deleteArray_rootcLcLTrajectory(void *p);
   static void destruct_rootcLcLTrajectory(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::Trajectory*)
   {
      ::root::Trajectory *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::Trajectory >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::Trajectory", ::root::Trajectory::Class_Version(), "", 42,
                  typeid(::root::Trajectory), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::Trajectory::Dictionary, isa_proxy, 4,
                  sizeof(::root::Trajectory) );
      instance.SetNew(&new_rootcLcLTrajectory);
      instance.SetNewArray(&newArray_rootcLcLTrajectory);
      instance.SetDelete(&delete_rootcLcLTrajectory);
      instance.SetDeleteArray(&deleteArray_rootcLcLTrajectory);
      instance.SetDestructor(&destruct_rootcLcLTrajectory);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::Trajectory*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::Trajectory*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::Trajectory*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_rootcLcLTPCHit(void *p = nullptr);
   static void *newArray_rootcLcLTPCHit(Long_t size, void *p);
   static void delete_rootcLcLTPCHit(void *p);
   static void deleteArray_rootcLcLTPCHit(void *p);
   static void destruct_rootcLcLTPCHit(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::TPCHit*)
   {
      ::root::TPCHit *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::TPCHit >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::TPCHit", ::root::TPCHit::Class_Version(), "", 55,
                  typeid(::root::TPCHit), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::TPCHit::Dictionary, isa_proxy, 4,
                  sizeof(::root::TPCHit) );
      instance.SetNew(&new_rootcLcLTPCHit);
      instance.SetNewArray(&newArray_rootcLcLTPCHit);
      instance.SetDelete(&delete_rootcLcLTPCHit);
      instance.SetDeleteArray(&deleteArray_rootcLcLTPCHit);
      instance.SetDestructor(&destruct_rootcLcLTPCHit);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::TPCHit*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::TPCHit*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::TPCHit*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_rootcLcLECalHit(void *p = nullptr);
   static void *newArray_rootcLcLECalHit(Long_t size, void *p);
   static void delete_rootcLcLECalHit(void *p);
   static void deleteArray_rootcLcLECalHit(void *p);
   static void destruct_rootcLcLECalHit(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::ECalHit*)
   {
      ::root::ECalHit *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::ECalHit >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::ECalHit", ::root::ECalHit::Class_Version(), "", 70,
                  typeid(::root::ECalHit), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::ECalHit::Dictionary, isa_proxy, 4,
                  sizeof(::root::ECalHit) );
      instance.SetNew(&new_rootcLcLECalHit);
      instance.SetNewArray(&newArray_rootcLcLECalHit);
      instance.SetDelete(&delete_rootcLcLECalHit);
      instance.SetDeleteArray(&deleteArray_rootcLcLECalHit);
      instance.SetDestructor(&destruct_rootcLcLECalHit);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::ECalHit*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::ECalHit*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::ECalHit*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_rootcLcLMuIDHit(void *p = nullptr);
   static void *newArray_rootcLcLMuIDHit(Long_t size, void *p);
   static void delete_rootcLcLMuIDHit(void *p);
   static void deleteArray_rootcLcLMuIDHit(void *p);
   static void destruct_rootcLcLMuIDHit(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::MuIDHit*)
   {
      ::root::MuIDHit *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::MuIDHit >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::MuIDHit", ::root::MuIDHit::Class_Version(), "", 87,
                  typeid(::root::MuIDHit), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::MuIDHit::Dictionary, isa_proxy, 4,
                  sizeof(::root::MuIDHit) );
      instance.SetNew(&new_rootcLcLMuIDHit);
      instance.SetNewArray(&newArray_rootcLcLMuIDHit);
      instance.SetDelete(&delete_rootcLcLMuIDHit);
      instance.SetDeleteArray(&deleteArray_rootcLcLMuIDHit);
      instance.SetDestructor(&destruct_rootcLcLMuIDHit);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::MuIDHit*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::MuIDHit*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::MuIDHit*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_rootcLcLParticle(void *p = nullptr);
   static void *newArray_rootcLcLParticle(Long_t size, void *p);
   static void delete_rootcLcLParticle(void *p);
   static void deleteArray_rootcLcLParticle(void *p);
   static void destruct_rootcLcLParticle(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::Particle*)
   {
      ::root::Particle *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::Particle >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::Particle", ::root::Particle::Class_Version(), "", 104,
                  typeid(::root::Particle), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::Particle::Dictionary, isa_proxy, 4,
                  sizeof(::root::Particle) );
      instance.SetNew(&new_rootcLcLParticle);
      instance.SetNewArray(&newArray_rootcLcLParticle);
      instance.SetDelete(&delete_rootcLcLParticle);
      instance.SetDeleteArray(&deleteArray_rootcLcLParticle);
      instance.SetDestructor(&destruct_rootcLcLParticle);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::Particle*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::Particle*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::Particle*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_rootcLcLEvent(void *p = nullptr);
   static void *newArray_rootcLcLEvent(Long_t size, void *p);
   static void delete_rootcLcLEvent(void *p);
   static void deleteArray_rootcLcLEvent(void *p);
   static void destruct_rootcLcLEvent(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::root::Event*)
   {
      ::root::Event *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::root::Event >(nullptr);
      static ::ROOT::TGenericClassInfo 
         instance("root::Event", ::root::Event::Class_Version(), "", 128,
                  typeid(::root::Event), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::root::Event::Dictionary, isa_proxy, 4,
                  sizeof(::root::Event) );
      instance.SetNew(&new_rootcLcLEvent);
      instance.SetNewArray(&newArray_rootcLcLEvent);
      instance.SetDelete(&delete_rootcLcLEvent);
      instance.SetDeleteArray(&deleteArray_rootcLcLEvent);
      instance.SetDestructor(&destruct_rootcLcLEvent);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::root::Event*)
   {
      return GenerateInitInstanceLocal(static_cast<::root::Event*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::root::Event*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace root {
//______________________________________________________________________________
atomic_TClass_ptr TrajectoryPoint::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *TrajectoryPoint::Class_Name()
{
   return "root::TrajectoryPoint";
}

//______________________________________________________________________________
const char *TrajectoryPoint::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::TrajectoryPoint*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int TrajectoryPoint::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::TrajectoryPoint*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *TrajectoryPoint::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::TrajectoryPoint*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *TrajectoryPoint::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::TrajectoryPoint*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
atomic_TClass_ptr MomentumPoint::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *MomentumPoint::Class_Name()
{
   return "root::MomentumPoint";
}

//______________________________________________________________________________
const char *MomentumPoint::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::MomentumPoint*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int MomentumPoint::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::MomentumPoint*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *MomentumPoint::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::MomentumPoint*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *MomentumPoint::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::MomentumPoint*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
atomic_TClass_ptr Trajectory::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *Trajectory::Class_Name()
{
   return "root::Trajectory";
}

//______________________________________________________________________________
const char *Trajectory::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::Trajectory*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int Trajectory::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::Trajectory*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *Trajectory::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::Trajectory*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *Trajectory::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::Trajectory*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
atomic_TClass_ptr TPCHit::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *TPCHit::Class_Name()
{
   return "root::TPCHit";
}

//______________________________________________________________________________
const char *TPCHit::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::TPCHit*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int TPCHit::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::TPCHit*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *TPCHit::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::TPCHit*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *TPCHit::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::TPCHit*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
atomic_TClass_ptr ECalHit::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *ECalHit::Class_Name()
{
   return "root::ECalHit";
}

//______________________________________________________________________________
const char *ECalHit::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::ECalHit*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int ECalHit::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::ECalHit*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *ECalHit::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::ECalHit*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *ECalHit::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::ECalHit*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
atomic_TClass_ptr MuIDHit::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *MuIDHit::Class_Name()
{
   return "root::MuIDHit";
}

//______________________________________________________________________________
const char *MuIDHit::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::MuIDHit*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int MuIDHit::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::MuIDHit*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *MuIDHit::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::MuIDHit*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *MuIDHit::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::MuIDHit*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
atomic_TClass_ptr Particle::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *Particle::Class_Name()
{
   return "root::Particle";
}

//______________________________________________________________________________
const char *Particle::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::Particle*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int Particle::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::Particle*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *Particle::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::Particle*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *Particle::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::Particle*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
atomic_TClass_ptr Event::fgIsA(nullptr);  // static to hold class pointer

//______________________________________________________________________________
const char *Event::Class_Name()
{
   return "root::Event";
}

//______________________________________________________________________________
const char *Event::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::Event*)nullptr)->GetImplFileName();
}

//______________________________________________________________________________
int Event::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::root::Event*)nullptr)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *Event::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::Event*)nullptr)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *Event::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::root::Event*)nullptr)->GetClass(); }
   return fgIsA;
}

} // namespace root
namespace root {
//______________________________________________________________________________
void TrajectoryPoint::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::TrajectoryPoint.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::TrajectoryPoint::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::TrajectoryPoint::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLTrajectoryPoint(void *p) {
      return  p ? new(p) ::root::TrajectoryPoint : new ::root::TrajectoryPoint;
   }
   static void *newArray_rootcLcLTrajectoryPoint(Long_t nElements, void *p) {
      return p ? new(p) ::root::TrajectoryPoint[nElements] : new ::root::TrajectoryPoint[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLTrajectoryPoint(void *p) {
      delete (static_cast<::root::TrajectoryPoint*>(p));
   }
   static void deleteArray_rootcLcLTrajectoryPoint(void *p) {
      delete [] (static_cast<::root::TrajectoryPoint*>(p));
   }
   static void destruct_rootcLcLTrajectoryPoint(void *p) {
      typedef ::root::TrajectoryPoint current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::TrajectoryPoint

namespace root {
//______________________________________________________________________________
void MomentumPoint::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::MomentumPoint.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::MomentumPoint::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::MomentumPoint::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLMomentumPoint(void *p) {
      return  p ? new(p) ::root::MomentumPoint : new ::root::MomentumPoint;
   }
   static void *newArray_rootcLcLMomentumPoint(Long_t nElements, void *p) {
      return p ? new(p) ::root::MomentumPoint[nElements] : new ::root::MomentumPoint[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLMomentumPoint(void *p) {
      delete (static_cast<::root::MomentumPoint*>(p));
   }
   static void deleteArray_rootcLcLMomentumPoint(void *p) {
      delete [] (static_cast<::root::MomentumPoint*>(p));
   }
   static void destruct_rootcLcLMomentumPoint(void *p) {
      typedef ::root::MomentumPoint current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::MomentumPoint

namespace root {
//______________________________________________________________________________
void Trajectory::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::Trajectory.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::Trajectory::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::Trajectory::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLTrajectory(void *p) {
      return  p ? new(p) ::root::Trajectory : new ::root::Trajectory;
   }
   static void *newArray_rootcLcLTrajectory(Long_t nElements, void *p) {
      return p ? new(p) ::root::Trajectory[nElements] : new ::root::Trajectory[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLTrajectory(void *p) {
      delete (static_cast<::root::Trajectory*>(p));
   }
   static void deleteArray_rootcLcLTrajectory(void *p) {
      delete [] (static_cast<::root::Trajectory*>(p));
   }
   static void destruct_rootcLcLTrajectory(void *p) {
      typedef ::root::Trajectory current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::Trajectory

namespace root {
//______________________________________________________________________________
void TPCHit::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::TPCHit.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::TPCHit::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::TPCHit::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLTPCHit(void *p) {
      return  p ? new(p) ::root::TPCHit : new ::root::TPCHit;
   }
   static void *newArray_rootcLcLTPCHit(Long_t nElements, void *p) {
      return p ? new(p) ::root::TPCHit[nElements] : new ::root::TPCHit[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLTPCHit(void *p) {
      delete (static_cast<::root::TPCHit*>(p));
   }
   static void deleteArray_rootcLcLTPCHit(void *p) {
      delete [] (static_cast<::root::TPCHit*>(p));
   }
   static void destruct_rootcLcLTPCHit(void *p) {
      typedef ::root::TPCHit current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::TPCHit

namespace root {
//______________________________________________________________________________
void ECalHit::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::ECalHit.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::ECalHit::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::ECalHit::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLECalHit(void *p) {
      return  p ? new(p) ::root::ECalHit : new ::root::ECalHit;
   }
   static void *newArray_rootcLcLECalHit(Long_t nElements, void *p) {
      return p ? new(p) ::root::ECalHit[nElements] : new ::root::ECalHit[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLECalHit(void *p) {
      delete (static_cast<::root::ECalHit*>(p));
   }
   static void deleteArray_rootcLcLECalHit(void *p) {
      delete [] (static_cast<::root::ECalHit*>(p));
   }
   static void destruct_rootcLcLECalHit(void *p) {
      typedef ::root::ECalHit current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::ECalHit

namespace root {
//______________________________________________________________________________
void MuIDHit::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::MuIDHit.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::MuIDHit::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::MuIDHit::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLMuIDHit(void *p) {
      return  p ? new(p) ::root::MuIDHit : new ::root::MuIDHit;
   }
   static void *newArray_rootcLcLMuIDHit(Long_t nElements, void *p) {
      return p ? new(p) ::root::MuIDHit[nElements] : new ::root::MuIDHit[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLMuIDHit(void *p) {
      delete (static_cast<::root::MuIDHit*>(p));
   }
   static void deleteArray_rootcLcLMuIDHit(void *p) {
      delete [] (static_cast<::root::MuIDHit*>(p));
   }
   static void destruct_rootcLcLMuIDHit(void *p) {
      typedef ::root::MuIDHit current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::MuIDHit

namespace root {
//______________________________________________________________________________
void Particle::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::Particle.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::Particle::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::Particle::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLParticle(void *p) {
      return  p ? new(p) ::root::Particle : new ::root::Particle;
   }
   static void *newArray_rootcLcLParticle(Long_t nElements, void *p) {
      return p ? new(p) ::root::Particle[nElements] : new ::root::Particle[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLParticle(void *p) {
      delete (static_cast<::root::Particle*>(p));
   }
   static void deleteArray_rootcLcLParticle(void *p) {
      delete [] (static_cast<::root::Particle*>(p));
   }
   static void destruct_rootcLcLParticle(void *p) {
      typedef ::root::Particle current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::Particle

namespace root {
//______________________________________________________________________________
void Event::Streamer(TBuffer &R__b)
{
   // Stream an object of class root::Event.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(root::Event::Class(),this);
   } else {
      R__b.WriteClassBuffer(root::Event::Class(),this);
   }
}

} // namespace root
namespace ROOT {
   // Wrappers around operator new
   static void *new_rootcLcLEvent(void *p) {
      return  p ? new(p) ::root::Event : new ::root::Event;
   }
   static void *newArray_rootcLcLEvent(Long_t nElements, void *p) {
      return p ? new(p) ::root::Event[nElements] : new ::root::Event[nElements];
   }
   // Wrapper around operator delete
   static void delete_rootcLcLEvent(void *p) {
      delete (static_cast<::root::Event*>(p));
   }
   static void deleteArray_rootcLcLEvent(void *p) {
      delete [] (static_cast<::root::Event*>(p));
   }
   static void destruct_rootcLcLEvent(void *p) {
      typedef ::root::Event current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::root::Event

namespace ROOT {
   static TClass *vectorlErootcLcLTrajectoryPointgR_Dictionary();
   static void vectorlErootcLcLTrajectoryPointgR_TClassManip(TClass*);
   static void *new_vectorlErootcLcLTrajectoryPointgR(void *p = nullptr);
   static void *newArray_vectorlErootcLcLTrajectoryPointgR(Long_t size, void *p);
   static void delete_vectorlErootcLcLTrajectoryPointgR(void *p);
   static void deleteArray_vectorlErootcLcLTrajectoryPointgR(void *p);
   static void destruct_vectorlErootcLcLTrajectoryPointgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<root::TrajectoryPoint>*)
   {
      vector<root::TrajectoryPoint> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<root::TrajectoryPoint>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<root::TrajectoryPoint>", -2, "vector", 423,
                  typeid(vector<root::TrajectoryPoint>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlErootcLcLTrajectoryPointgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<root::TrajectoryPoint>) );
      instance.SetNew(&new_vectorlErootcLcLTrajectoryPointgR);
      instance.SetNewArray(&newArray_vectorlErootcLcLTrajectoryPointgR);
      instance.SetDelete(&delete_vectorlErootcLcLTrajectoryPointgR);
      instance.SetDeleteArray(&deleteArray_vectorlErootcLcLTrajectoryPointgR);
      instance.SetDestructor(&destruct_vectorlErootcLcLTrajectoryPointgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<root::TrajectoryPoint> >()));

      instance.AdoptAlternate(::ROOT::AddClassAlternate("vector<root::TrajectoryPoint>","std::vector<root::TrajectoryPoint, std::allocator<root::TrajectoryPoint> >"));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const vector<root::TrajectoryPoint>*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlErootcLcLTrajectoryPointgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal(static_cast<const vector<root::TrajectoryPoint>*>(nullptr))->GetClass();
      vectorlErootcLcLTrajectoryPointgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlErootcLcLTrajectoryPointgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlErootcLcLTrajectoryPointgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::TrajectoryPoint> : new vector<root::TrajectoryPoint>;
   }
   static void *newArray_vectorlErootcLcLTrajectoryPointgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::TrajectoryPoint>[nElements] : new vector<root::TrajectoryPoint>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlErootcLcLTrajectoryPointgR(void *p) {
      delete (static_cast<vector<root::TrajectoryPoint>*>(p));
   }
   static void deleteArray_vectorlErootcLcLTrajectoryPointgR(void *p) {
      delete [] (static_cast<vector<root::TrajectoryPoint>*>(p));
   }
   static void destruct_vectorlErootcLcLTrajectoryPointgR(void *p) {
      typedef vector<root::TrajectoryPoint> current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class vector<root::TrajectoryPoint>

namespace ROOT {
   static TClass *vectorlErootcLcLTPCHitgR_Dictionary();
   static void vectorlErootcLcLTPCHitgR_TClassManip(TClass*);
   static void *new_vectorlErootcLcLTPCHitgR(void *p = nullptr);
   static void *newArray_vectorlErootcLcLTPCHitgR(Long_t size, void *p);
   static void delete_vectorlErootcLcLTPCHitgR(void *p);
   static void deleteArray_vectorlErootcLcLTPCHitgR(void *p);
   static void destruct_vectorlErootcLcLTPCHitgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<root::TPCHit>*)
   {
      vector<root::TPCHit> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<root::TPCHit>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<root::TPCHit>", -2, "vector", 423,
                  typeid(vector<root::TPCHit>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlErootcLcLTPCHitgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<root::TPCHit>) );
      instance.SetNew(&new_vectorlErootcLcLTPCHitgR);
      instance.SetNewArray(&newArray_vectorlErootcLcLTPCHitgR);
      instance.SetDelete(&delete_vectorlErootcLcLTPCHitgR);
      instance.SetDeleteArray(&deleteArray_vectorlErootcLcLTPCHitgR);
      instance.SetDestructor(&destruct_vectorlErootcLcLTPCHitgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<root::TPCHit> >()));

      instance.AdoptAlternate(::ROOT::AddClassAlternate("vector<root::TPCHit>","std::vector<root::TPCHit, std::allocator<root::TPCHit> >"));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const vector<root::TPCHit>*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlErootcLcLTPCHitgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal(static_cast<const vector<root::TPCHit>*>(nullptr))->GetClass();
      vectorlErootcLcLTPCHitgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlErootcLcLTPCHitgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlErootcLcLTPCHitgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::TPCHit> : new vector<root::TPCHit>;
   }
   static void *newArray_vectorlErootcLcLTPCHitgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::TPCHit>[nElements] : new vector<root::TPCHit>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlErootcLcLTPCHitgR(void *p) {
      delete (static_cast<vector<root::TPCHit>*>(p));
   }
   static void deleteArray_vectorlErootcLcLTPCHitgR(void *p) {
      delete [] (static_cast<vector<root::TPCHit>*>(p));
   }
   static void destruct_vectorlErootcLcLTPCHitgR(void *p) {
      typedef vector<root::TPCHit> current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class vector<root::TPCHit>

namespace ROOT {
   static TClass *vectorlErootcLcLParticlegR_Dictionary();
   static void vectorlErootcLcLParticlegR_TClassManip(TClass*);
   static void *new_vectorlErootcLcLParticlegR(void *p = nullptr);
   static void *newArray_vectorlErootcLcLParticlegR(Long_t size, void *p);
   static void delete_vectorlErootcLcLParticlegR(void *p);
   static void deleteArray_vectorlErootcLcLParticlegR(void *p);
   static void destruct_vectorlErootcLcLParticlegR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<root::Particle>*)
   {
      vector<root::Particle> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<root::Particle>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<root::Particle>", -2, "vector", 423,
                  typeid(vector<root::Particle>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlErootcLcLParticlegR_Dictionary, isa_proxy, 4,
                  sizeof(vector<root::Particle>) );
      instance.SetNew(&new_vectorlErootcLcLParticlegR);
      instance.SetNewArray(&newArray_vectorlErootcLcLParticlegR);
      instance.SetDelete(&delete_vectorlErootcLcLParticlegR);
      instance.SetDeleteArray(&deleteArray_vectorlErootcLcLParticlegR);
      instance.SetDestructor(&destruct_vectorlErootcLcLParticlegR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<root::Particle> >()));

      instance.AdoptAlternate(::ROOT::AddClassAlternate("vector<root::Particle>","std::vector<root::Particle, std::allocator<root::Particle> >"));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const vector<root::Particle>*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlErootcLcLParticlegR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal(static_cast<const vector<root::Particle>*>(nullptr))->GetClass();
      vectorlErootcLcLParticlegR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlErootcLcLParticlegR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlErootcLcLParticlegR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::Particle> : new vector<root::Particle>;
   }
   static void *newArray_vectorlErootcLcLParticlegR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::Particle>[nElements] : new vector<root::Particle>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlErootcLcLParticlegR(void *p) {
      delete (static_cast<vector<root::Particle>*>(p));
   }
   static void deleteArray_vectorlErootcLcLParticlegR(void *p) {
      delete [] (static_cast<vector<root::Particle>*>(p));
   }
   static void destruct_vectorlErootcLcLParticlegR(void *p) {
      typedef vector<root::Particle> current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class vector<root::Particle>

namespace ROOT {
   static TClass *vectorlErootcLcLMuIDHitgR_Dictionary();
   static void vectorlErootcLcLMuIDHitgR_TClassManip(TClass*);
   static void *new_vectorlErootcLcLMuIDHitgR(void *p = nullptr);
   static void *newArray_vectorlErootcLcLMuIDHitgR(Long_t size, void *p);
   static void delete_vectorlErootcLcLMuIDHitgR(void *p);
   static void deleteArray_vectorlErootcLcLMuIDHitgR(void *p);
   static void destruct_vectorlErootcLcLMuIDHitgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<root::MuIDHit>*)
   {
      vector<root::MuIDHit> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<root::MuIDHit>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<root::MuIDHit>", -2, "vector", 423,
                  typeid(vector<root::MuIDHit>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlErootcLcLMuIDHitgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<root::MuIDHit>) );
      instance.SetNew(&new_vectorlErootcLcLMuIDHitgR);
      instance.SetNewArray(&newArray_vectorlErootcLcLMuIDHitgR);
      instance.SetDelete(&delete_vectorlErootcLcLMuIDHitgR);
      instance.SetDeleteArray(&deleteArray_vectorlErootcLcLMuIDHitgR);
      instance.SetDestructor(&destruct_vectorlErootcLcLMuIDHitgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<root::MuIDHit> >()));

      instance.AdoptAlternate(::ROOT::AddClassAlternate("vector<root::MuIDHit>","std::vector<root::MuIDHit, std::allocator<root::MuIDHit> >"));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const vector<root::MuIDHit>*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlErootcLcLMuIDHitgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal(static_cast<const vector<root::MuIDHit>*>(nullptr))->GetClass();
      vectorlErootcLcLMuIDHitgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlErootcLcLMuIDHitgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlErootcLcLMuIDHitgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::MuIDHit> : new vector<root::MuIDHit>;
   }
   static void *newArray_vectorlErootcLcLMuIDHitgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::MuIDHit>[nElements] : new vector<root::MuIDHit>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlErootcLcLMuIDHitgR(void *p) {
      delete (static_cast<vector<root::MuIDHit>*>(p));
   }
   static void deleteArray_vectorlErootcLcLMuIDHitgR(void *p) {
      delete [] (static_cast<vector<root::MuIDHit>*>(p));
   }
   static void destruct_vectorlErootcLcLMuIDHitgR(void *p) {
      typedef vector<root::MuIDHit> current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class vector<root::MuIDHit>

namespace ROOT {
   static TClass *vectorlErootcLcLMomentumPointgR_Dictionary();
   static void vectorlErootcLcLMomentumPointgR_TClassManip(TClass*);
   static void *new_vectorlErootcLcLMomentumPointgR(void *p = nullptr);
   static void *newArray_vectorlErootcLcLMomentumPointgR(Long_t size, void *p);
   static void delete_vectorlErootcLcLMomentumPointgR(void *p);
   static void deleteArray_vectorlErootcLcLMomentumPointgR(void *p);
   static void destruct_vectorlErootcLcLMomentumPointgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<root::MomentumPoint>*)
   {
      vector<root::MomentumPoint> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<root::MomentumPoint>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<root::MomentumPoint>", -2, "vector", 423,
                  typeid(vector<root::MomentumPoint>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlErootcLcLMomentumPointgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<root::MomentumPoint>) );
      instance.SetNew(&new_vectorlErootcLcLMomentumPointgR);
      instance.SetNewArray(&newArray_vectorlErootcLcLMomentumPointgR);
      instance.SetDelete(&delete_vectorlErootcLcLMomentumPointgR);
      instance.SetDeleteArray(&deleteArray_vectorlErootcLcLMomentumPointgR);
      instance.SetDestructor(&destruct_vectorlErootcLcLMomentumPointgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<root::MomentumPoint> >()));

      instance.AdoptAlternate(::ROOT::AddClassAlternate("vector<root::MomentumPoint>","std::vector<root::MomentumPoint, std::allocator<root::MomentumPoint> >"));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const vector<root::MomentumPoint>*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlErootcLcLMomentumPointgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal(static_cast<const vector<root::MomentumPoint>*>(nullptr))->GetClass();
      vectorlErootcLcLMomentumPointgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlErootcLcLMomentumPointgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlErootcLcLMomentumPointgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::MomentumPoint> : new vector<root::MomentumPoint>;
   }
   static void *newArray_vectorlErootcLcLMomentumPointgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::MomentumPoint>[nElements] : new vector<root::MomentumPoint>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlErootcLcLMomentumPointgR(void *p) {
      delete (static_cast<vector<root::MomentumPoint>*>(p));
   }
   static void deleteArray_vectorlErootcLcLMomentumPointgR(void *p) {
      delete [] (static_cast<vector<root::MomentumPoint>*>(p));
   }
   static void destruct_vectorlErootcLcLMomentumPointgR(void *p) {
      typedef vector<root::MomentumPoint> current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class vector<root::MomentumPoint>

namespace ROOT {
   static TClass *vectorlErootcLcLECalHitgR_Dictionary();
   static void vectorlErootcLcLECalHitgR_TClassManip(TClass*);
   static void *new_vectorlErootcLcLECalHitgR(void *p = nullptr);
   static void *newArray_vectorlErootcLcLECalHitgR(Long_t size, void *p);
   static void delete_vectorlErootcLcLECalHitgR(void *p);
   static void deleteArray_vectorlErootcLcLECalHitgR(void *p);
   static void destruct_vectorlErootcLcLECalHitgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<root::ECalHit>*)
   {
      vector<root::ECalHit> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<root::ECalHit>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<root::ECalHit>", -2, "vector", 423,
                  typeid(vector<root::ECalHit>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlErootcLcLECalHitgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<root::ECalHit>) );
      instance.SetNew(&new_vectorlErootcLcLECalHitgR);
      instance.SetNewArray(&newArray_vectorlErootcLcLECalHitgR);
      instance.SetDelete(&delete_vectorlErootcLcLECalHitgR);
      instance.SetDeleteArray(&deleteArray_vectorlErootcLcLECalHitgR);
      instance.SetDestructor(&destruct_vectorlErootcLcLECalHitgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<root::ECalHit> >()));

      instance.AdoptAlternate(::ROOT::AddClassAlternate("vector<root::ECalHit>","std::vector<root::ECalHit, std::allocator<root::ECalHit> >"));
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const vector<root::ECalHit>*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlErootcLcLECalHitgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal(static_cast<const vector<root::ECalHit>*>(nullptr))->GetClass();
      vectorlErootcLcLECalHitgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlErootcLcLECalHitgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlErootcLcLECalHitgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::ECalHit> : new vector<root::ECalHit>;
   }
   static void *newArray_vectorlErootcLcLECalHitgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<root::ECalHit>[nElements] : new vector<root::ECalHit>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlErootcLcLECalHitgR(void *p) {
      delete (static_cast<vector<root::ECalHit>*>(p));
   }
   static void deleteArray_vectorlErootcLcLECalHitgR(void *p) {
      delete [] (static_cast<vector<root::ECalHit>*>(p));
   }
   static void destruct_vectorlErootcLcLECalHitgR(void *p) {
      typedef vector<root::ECalHit> current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class vector<root::ECalHit>

namespace {
  void TriggerDictionaryInitialization_libROOTDataDict_Impl() {
    static const char* headers[] = {
"0",
nullptr
    };
    static const char* includePaths[] = {
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_28_12/Linux64bit+3.10-2.17-e26-p3915-prof/include",
"/exp/dune/app/users/jmartin4/FastGArSim/detector_simulation/include",
"/exp/dune/app/users/jmartin4/FastGArSim/detector_simulation",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_28_12/Linux64bit+3.10-2.17-e26-p3915-prof/include/",
"/exp/dune/app/users/jmartin4/FastGArSim/detector_simulation/build/",
nullptr
    };
    static const char* fwdDeclCode = R"DICTFWDDCLS(
#line 1 "libROOTDataDict dictionary forward declarations' payload"
#pragma clang diagnostic ignored "-Wkeyword-compat"
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
extern int __Cling_AutoLoading_Map;
namespace root{class TrajectoryPoint;}
namespace std{template <typename _Tp> class __attribute__((annotate("$clingAutoload$bits/allocator.h")))  __attribute__((annotate("$clingAutoload$string")))  allocator;
}
namespace root{class MomentumPoint;}
namespace root{class TPCHit;}
namespace root{class ECalHit;}
namespace root{class MuIDHit;}
namespace root{class Particle;}
namespace root{class Trajectory;}
namespace root{class Event;}
)DICTFWDDCLS";
    static const char* payloadCode = R"DICTPAYLOAD(
#line 1 "libROOTDataDict dictionary payload"


#define _BACKWARD_BACKWARD_WARNING_H
// Inline headers
#ifndef ROOTDATATYPES_HH
#define ROOTDATATYPES_HH

#include <vector>
#include <string>
#include "TObject.h"
#include "TString.h"

// ROOT-friendly data classes (no Geant4 dependencies)

namespace root {

    class TrajectoryPoint : public TObject
    {
        public:
        TrajectoryPoint() : x(0), y(0), z(0), time(0) {}
        
        TrajectoryPoint(Double_t px, Double_t py, Double_t pz, Double_t t) 
            : x(px), y(py), z(pz), time(t) {}
        
        Double_t x, y, z;
        Double_t time;

        ClassDef(TrajectoryPoint, 1)
    };

    class MomentumPoint : public TObject
    {
        public:
        MomentumPoint() : x(0), y(0), z(0) {}
        
        MomentumPoint(Double_t px, Double_t py, Double_t pz) 
            : x(px), y(py), z(pz){}
        
        Double_t x, y, z;

        ClassDef(MomentumPoint, 1)
    };

    class Trajectory : public TObject
    {
        public:
        Trajectory() = default;
        
        std::vector<TrajectoryPoint> points;
        std::vector<MomentumPoint> mom_points;
        TString start_vol_name;
        TString stop_vol_name;

        ClassDef(Trajectory, 1)
    };

    class TPCHit : public TObject
    {
        public:
        TPCHit() : x(0), y(0), z(0), energyDeposit(0), stepSize(0) {}
        
        TPCHit(Double_t px, Double_t py, Double_t pz, Double_t edep, Double_t step) 
            : x(px), y(py), z(pz), energyDeposit(edep), stepSize(step) {}
        
        Double_t x, y, z;
        Double_t energyDeposit;
        Double_t stepSize;

        ClassDef(TPCHit, 1)
    };

    class ECalHit : public TObject
    {
        public:
        ECalHit() : x(0), y(0), z(0), time(0), energyDeposit(0), layer(0), detID(0) {}
        
        ECalHit(Double_t px, Double_t py, Double_t pz, Double_t t, Double_t edep, Int_t l, Int_t id) 
            : x(px), y(py), z(pz), time(t), energyDeposit(edep), layer(l), detID(id) {}
        
        Double_t x, y, z;
        Double_t time;
        Double_t energyDeposit;
        Int_t layer;
        Int_t detID;

        ClassDef(ECalHit, 1)
    };

    class MuIDHit : public TObject
    {
        public:
        MuIDHit() : x(0), y(0), z(0), time(0), energyDeposit(0), layer(0), detID(0) {}
        
        MuIDHit(Double_t px, Double_t py, Double_t pz, Double_t t, Double_t edep, Int_t l, Int_t id) 
            : x(px), y(py), z(pz), time(t), energyDeposit(edep), layer(l), detID(id) {}
        
        Double_t x, y, z;
        Double_t time;
        Double_t energyDeposit;
        Int_t layer;
        Int_t detID;

        ClassDef(MuIDHit, 1)
    };

    class Particle : public TObject
    {
        public:
        Particle() : trackID(0), pdgCode(0), creatorProcess(""), endProcess(""), motherID(0) {}
        
        Particle(Int_t id, Int_t pdg, const TString& process, const TString& end_process, Int_t momid) 
            : trackID(id), pdgCode(pdg), creatorProcess(process), endProcess(end_process), motherID(momid) {}
        
        Int_t trackID;
        Int_t pdgCode;
        TString creatorProcess;
        TString endProcess;
        Int_t motherID;
        Trajectory trajectory;
        std::vector<TPCHit> tpcHits;
        std::vector<ECalHit> ecalHits;
        std::vector<MuIDHit> muidHits;
        std::vector<TPCHit> sec_tpcHits;
        std::vector<ECalHit> sec_ecalHits;
        std::vector<MuIDHit> sec_muidHits;

        ClassDef(Particle, 1)
    };

    class Event : public TObject
    {
        public:
        Event() : eventID(0) {}
        
        Event(Int_t id) : eventID(id) {}
        
        Int_t eventID;
        std::vector<Particle> particles;

        ClassDef(Event, 1)
    };

} // namespace root

#endif
#undef  _BACKWARD_BACKWARD_WARNING_H
)DICTPAYLOAD";
    static const char* classesHeaders[] = {
"root::ECalHit", payloadCode, "@",
"root::Event", payloadCode, "@",
"root::MomentumPoint", payloadCode, "@",
"root::MuIDHit", payloadCode, "@",
"root::Particle", payloadCode, "@",
"root::TPCHit", payloadCode, "@",
"root::Trajectory", payloadCode, "@",
"root::TrajectoryPoint", payloadCode, "@",
nullptr
};
    static bool isInitialized = false;
    if (!isInitialized) {
      TROOT::RegisterModule("libROOTDataDict",
        headers, includePaths, payloadCode, fwdDeclCode,
        TriggerDictionaryInitialization_libROOTDataDict_Impl, {}, classesHeaders, /*hasCxxModule*/false);
      isInitialized = true;
    }
  }
  static struct DictInit {
    DictInit() {
      TriggerDictionaryInitialization_libROOTDataDict_Impl();
    }
  } __TheDictionaryInitializer;
}
void TriggerDictionaryInitialization_libROOTDataDict() {
  TriggerDictionaryInitialization_libROOTDataDict_Impl();
}
